jQuery(document).ready(function(){
  //$('#phone').inputmask("99-9999999");  //static mask
    
  $('#phone-1').inputmask({"mask": "(999) 999-9999"});
    $('#mobile-1').inputmask({"mask": "(999) 999-9999"}); //specifying options
    
     $('#phone-2').inputmask({"mask": "(999) 999-9999"});
    $('#mobile-2').inputmask({"mask": "(999) 999-9999"}); //specifying options
    
      $('#phone-3').inputmask({"mask": "(999) 999-9999"});
    $('#mobile-3').inputmask({"mask": "(999) 999-9999"}); //specifying options
    
    
});

 

$('#datepicker-1').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-2').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-3').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-4').datepicker({
            uiLibrary: 'bootstrap4'
});
 $('#datepicker-5').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-6').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-7').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-8').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-9').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-10').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-11').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-12').datepicker({
            uiLibrary: 'bootstrap4'
});
$('#datepicker-13').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-14').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-15').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-16').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-17').datepicker({
            uiLibrary: 'bootstrap4'
}); 
$('#datepicker-18').datepicker({
            uiLibrary: 'bootstrap4'
});

 $('#datepicker-19').datepicker({
            uiLibrary: 'bootstrap4'
});
